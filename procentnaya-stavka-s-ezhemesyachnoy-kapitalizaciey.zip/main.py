import math
import time
print('Пожалуйста, введите свое имя:', end=' ')
name = input()
print('\nДоброго времени суток, %s!'%name, '\nВы запустили программу, которая расчитывает и начисляет проценты по вкладам.\nКлючевой элемент программы - вид капитализации.\n')
time.sleep(1)
print('Вам известно понятие КАПИТАЛИЗАЦИЯ?(1.Да/2.Нет)')
capitalization = input().lower().strip()
if capitalization == 'no' or capitalization == 'нет' or capitalization == '2.' or capitalization == '2':
    print("""\nКапитализация - это особый способ начисления и расчета процентов.\nНа вклады с капитализацией проценты начисляются поэтапно — например,\nраз в месяц — и прибавляются к основной сумме депозита.\nЭто значит, что в следующем периоде проценты будут начисляться уже на новое\nтело вклада, и выгода вкладчика будет больше.\n""")
    time.sleep(3)
print("""\nПожалуйста, выберите ваш вид капитализации процентов(1.Ежемесячная/2.Ежеквартальная/3.Ежегодная):
1. Ежемесячная – срок начисления процентов на денежные средства клиента составляет 1 календарный месяц.
2. Ежеквартальная – каждые 4 месяца происходит начисление процентов на сумму, хранящуюся на счёту банка.
3. Ежегодная – проценты по вкладу начисляются лишь 1 раз в год.""")
deposit = input().lower().strip() # какой вид капитализации выбирает пользователь#
    
    
#Если пользователь выбрал ежемесячный вид капитализации процентов#
if deposit == 'ежемесячная' or deposit == '1' or deposit == '1.' or deposit == 'ежемесячный': 
    print('\nПредусматривает ли ваш вклад возможность внесения определенных сумм ежемесячно?(1.Да/2.Нет)')
    answer = input().lower().strip()
    if answer == 'yes' or answer == 'да' or answer == '1.' or answer == '1':
        print('Введите начальную сумму:', end=' ')
        body = int(input())     # Первоначальный взнос #
        print('Введите процентную ставку:', end=' ')
        percent = input().translate({ord('%'): None})
        percent = float(percent)  # процентная ставка годовых #
        print('Введите количество месяцев:', end=' ')
        months = int(input()) # количество месяцев #
        summ = 0 
        z = body
        print('Вы планируете вносить одинаковую сумму?(1.Да/2.Нет)')
        answer_monthly = input().lower().strip()
        if answer_monthly == 'no' or answer_monthly == 'not' or answer_monthly == '2.' or answer_monthly == '2' or answer_monthly == 'нет' or answer_monthly == 'ytn':
            for i in range(months):
                if i == 1:
                    print('Введите сумму, которую внесли вo', i+1, 'месяц:', end=' ') 
                else: 
                    if i == 0:
                        print('\nВведите сумму, которую внесли в', i+1, 'месяц:',end=' ')
                    else:
                        print('Введите сумму, которую внесли в', i+1, 'месяц:',end=' ')
                k = int(input()) #ежемесячное пополнение#
                summ += k 
                body += k 
                body = body + body * percent / 1200
            print('\n', '_'*133, sep='')
            print('\nВаша итоговая сумма составит: ', round(body, 2), '\nИз них внесено вами: ', z + summ, '\nВаша прибыль составит: ', round(body-z-summ, 2))
        elif answer_monthly == 'yes' or answer_monthly == 'да' or answer_monthly == '1.' or answer_monthly == '1':
            print('\nПожалуйста, введите сумму, на которую планируете пополнять счет ежемесячно:', end=' ')
            constant = float(input())
            for i in range(months):
                summ += constant 
                body += constant 
                body = body + body * percent / 1200
            print('\n', '_'*133, sep='')
            print('\nВаша итоговая сумма составит: ', round(body, 2), '\nИз них внесено вами: ', z + summ, '\nВаша прибыль составит: ', round(body-z-summ, 2))
    elif answer == 'no' or answer == 'not' or answer == '2.' or answer == '2' or answer == 'нет' or answer == 'ytn':
        print('Введите сумму вклада:', end=' ')
        body = int(input())     # Тело капитала #
        print('Введите процентную ставку:', end=' ')
        percent = input().translate({ord('%'): None})
        percent = float(percent)  # процентная ставка годовых #
        print('Введите количество месяцев:', end=' ')
        months = int(input()) # количество месяцев #
        k = body
        for i in range(months):
            body = body + body * percent / 1200
        print('\n','_'*133, sep='')
        print('\nВаша итоговая сумма составит: ', round(body, 2), '\nИз них внесено вами: ', k, '\nВаша прибыль составит: ', round(body-k, 2))
   
   
    #Если пользователь выбрал ежеквартальный вид капитализации процентов#
elif  deposit == 'ежеквартальная' or deposit == '2' or deposit == '2.' or deposit == 'ежеквартальный':
    print('\nПредусматривает ли ваш вклад возможность внесения определенных сумм ежемесячно?(1.Да/2.Нет)')
    answer = input().lower().strip()
    if answer == 'yes' or answer == 'да' or answer == '1.' or answer == '1':
        print('Введите начальную сумму:', end=' ')
        body = int(input())     # Первоначальный взнос #
        print('Введите процентную ставку:', end=' ')
        percent = input().translate({ord('%'): None})
        percent = float(percent)  # процентная ставка годовых #
        print('Введите количество месяцев (желательно, кратное 4):', end=' ')
        months = int(input())    # количество месяцев #
        summ = 0
        z = body
        print('Вы планируете вносить одинаковую сумму ежемесячно?(1.Да/2.Нет)')
        answer_monthly = input().lower().strip()
        if answer_monthly == 'no' or answer_monthly == 'not' or answer_monthly == '2.' or answer_monthly == '2' or answer_monthly == 'нет' or answer_monthly == 'ytn':
            for i in range(months):
                if i == 1:
                    print('Введите сумму, которую внесли вo', i+1, 'месяц:', end=' ') 
                else:
                    print('Введите сумму, которую внесли в', i+1, 'месяц:', end=' ')
                k = int(input())
                summ += k
                body += k 
                if (i + 1) % 4 == 0:
                    body = body + body * percent / 400
            print('\n', '_'*133, sep='')
            print('\nВаша итоговая сумма составит: ', round(body, 2), '\nИз них внесено вами: ', z + summ, '\nВаша прибыль составит: ', round(body-z-summ, 2))    
        elif answer_monthly == 'yes' or answer_monthly == 'да' or answer_monthly == '1.' or answer_monthly == '1':    
            print('Пожалуйста, введите сумму, на которую планируете пополнять счет ежемесячно:', end=' ')
            constant = float(input())
            for i in range(months):
                summ += constant
                body += constant 
                if (i + 1) % 4 == 0:
                    body = body + body * percent / 400
            print('\n', '_'*133, sep='')
            print('\nВаша итоговая сумма составит: ', round(body, 2), '\nИз них внесено вами: ', summ+z, '\nВаша прибыль составит: ', round(body-z-summ, 2))
    elif answer == 'no' or answer == 'not' or answer == '2.' or answer == '2' or answer == 'нет' or answer == 'ytn':
        print('Введите начальную сумму:', end=' ')
        body = int(input())     # Взнос #
        print('Введите процентную ставку:', end=' ')
        percent = input().translate({ord('%'): None})
        percent = float(percent)  # процентная ставка годовых #
        print('На сколько месяцев вы бы хотели положить деньги в банк? (желательно кратное 4)')
        months = int(input())    # количество месяцев #
        k = body
        for i in range(months):
            if (i + 1) % 4 == 0:
                body = body + body * percent / 400
        print('\n', '_'*133, sep='')
        print('\nВаша итоговая сумма составит: ', round(body, 2), '\nИз них внесено вами: ', k, '\nВаша прибыль составит: ', round(body-k, 2))
    
    
    #Если пользователь выбрал ежегодный вид капитализации процентов#
elif deposit == 'ежегодная' or  deposit == '3' or  deposit == '3.' or  deposit == 'ежегодный':
    print('Предусматривает ли ваш вклад возможность внесения определенных сумм ежемесячно?(1.Да/2.Нет)')
    answer = input().lower().strip()
    if answer == 'yes' or answer == 'да' or answer == '1.' or answer == '1':
        print('Введите начальную сумму:', end=' ')
        body = int(input())     # Первоначальный взнос #
        print('Введите процентную ставку:', end=' ')
        percent = input().translate({ord('%'): None})
        percent = float(percent)  # процентная ставка годовых #
        print('На сколько лет вы бы хотели положить деньги в банк?')
        year = int(input())    # количество лет #
        z = body
        summ = 0
        print('Вы планируете вносить одинаковую сумму ежемесячно?(1.Да/2.Нет)')
        answer_monthly = input().lower().strip()
        if answer_monthly == 'no' or answer_monthly == 'not' or answer_monthly == '2.' or answer_monthly == '2' or answer_monthly == 'нет' or answer_monthly == 'ytn':
            for i in range(year):
                for j in range(12):
                    if j == 1:
                        print('Введите сумму, которую внесли вo', j+1, 'месяц:', end=' ') 
                    else: 
                        print('Введите сумму, которую внесли в', j+1, 'месяц:', end=' ')
                    k = int(input())
                    summ +=k
                    body += k 
                    if (j + 1) % 12 == 0:
                        body = body + body * percent / 100
                        if j + 1 >= year * 12:
                            continue
                        else:    
                            print ('Ваша сумма в конце года составит: ', math.floor(body), '\n')
            print('\n', '_'*133, sep='')
            if year == 1:
                print('Ваша итоговая сумма за 1 год составит: ', round(body, 2), '\nИз них внесено вами: ', z + summ, '\nВаша прибыль составит: ', round(body-z-summ, 2))
            elif 2 <= year < 5:
                print('Ваша итоговая сумма за %d годa составит: '%year, round(body, 2), '\nИз них внесено вами: ', z + summ, '\nВаша прибыль составит: ', round(body-z-summ, 2))
            elif year >= 5:
                print('Ваша итоговая сумма за %d лет составит: '%year, round(body, 2), '\nИз них внесено вами: ', z + summ, '\nВаша прибыль составит: ', round(body-z-summ, 2))
        elif answer_monthly == 'yes' or answer_monthly == 'да' or answer_monthly == '1.' or answer_monthly == '1':    
            print('Пожалуйста, введите сумму, на которую планируете пополнять счет ежемесячно:', end=' ')
            constant = float(input())
            for i in range(year):
                for j in range(12):
                    summ += constant
                    body += constant 
                    if (j + 1) % 12 == 0:
                        body = body + body * percent / 100
                        if j + 1 >= year * 12:
                            continue
                        else:
                            if i == 0:
                                print ('\nВаша сумма в конце года составит: ', math.floor(body))
                            else:
                                print ('Ваша сумма в конце года составит: ', math.floor(body))
            print('\n', '_'*133, sep='')
            if year == 1:
                print('\nВаша итоговая сумма за 1 год составит: ', round(body, 2), '\nИз них внесено вами: ', z + summ, '\nВаша прибыль составит: ', round(body-z-summ, 2))
            elif 2 <= year < 5:
                print('\nВаша итоговая сумма за %d годa составит: '%year, round(body, 2), '\nИз них внесено вами: ', z + summ, '\nВаша прибыль составит: ', round(body-z-summ, 2))
            elif year >= 5:
                print('\nВаша итоговая сумма за %d лет составит: '%year, round(body, 2), '\nИз них внесено вами: ', z + summ, '\nВаша прибыль составит: ', round(body-z-summ, 2))
    
    elif answer == 'no' or answer == 'not' or answer == '2.' or answer == '2' or answer == 'нет' or answer == 'ytn':
        print('Введите сумму вклада:', end=' ')
        body = int(input())     # Взнос #
        print('Введите процентную ставку:', end=' ')
        percent = input().translate({ord('%'): None})
        percent = float(percent)  # процентная ставка годовых #
        print('На сколько лет вы бы хотели положить деньги в банк?')
        year = int(input())    # количество лет #
        k = body
        for i in range(year):
            body = body + body * percent / 100
        print('\n', '_'*133, sep='')
        if year == 1:
            print('Ваша итоговая сумма за 1 год составит: ', round(body, 2), '\nИз них внесено вами: ', k, '\nВаша прибыль составит: ', round(body-k, 2))
        elif 2 <= year < 5:
            print('Ваша итоговая сумма за %d годa составит: '%year, round(body, 2), '\nИз них внесено вами: ', k, '\nВаша прибыль составит: ', round(body-k, 2))
        elif year >= 5:
            print('Ваша итоговая сумма за %d лет составит: '%year, round(body, 2), '\nИз них внесено вами: ', k, '\nВаша прибыль составит: ', round(body-k, 2))
                    
                
        
    
    
    














